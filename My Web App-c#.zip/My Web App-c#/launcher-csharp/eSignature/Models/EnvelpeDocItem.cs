﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DocuSign.CodeExamples.Models
{
    public class EnvelopeDocItem
    {
        public string Name { get; set; }
        public string Type { get; set; }
        public string DocumentId { get; set; }
    }
}
